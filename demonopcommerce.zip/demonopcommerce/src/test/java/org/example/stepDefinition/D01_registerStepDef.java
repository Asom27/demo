package org.example.stepDefinition;

import io.cucumber.java.en.And;
        import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P01_register;
import org.openqa.selenium.By;
        import org.testng.asserts.SoftAssert;

public class D01_registerStepDef {
    P01_register register=new P01_register();
    @Given("go to register page")
    public void registerTab()
    {
        Hooks.driver.findElement(register.registerTab()).click();

    }
    @When ("user enter personal data")
    public void enterPersonalData()
    {

        Hooks.driver.findElement(register.gender()).click();
        Hooks.driver.findElement(register.firstName ()).sendKeys("Esraa");
        Hooks.driver.findElement(register.lastName()).sendKeys("Sanad");
        Hooks.driver.findElement(register.date("DateOfBirthDay","27")).click();
        Hooks.driver.findElement(register.date("DateOfBirthMonth","2")).click();
        Hooks.driver.findElement(register.date("DateOfBirthYear","1993")).click();
        Hooks.driver.findElement(register.email()).sendKeys("esraa71@gmail.com");

    }
    @And("enter valid data to Company Details")
    public void enterCompanyData()
    {
        Hooks.driver.findElement(register.company()).sendKeys("Upwork");

    }
    @Then("enter valid Password")
    public void enterPasswordData()
    {
        Hooks.driver.findElement(register.password()).sendKeys("password272");
        Hooks.driver.findElement(register.confirmPassword()).sendKeys("password272");
    }
    @And("click on register button")
    public void registerButton()
    {
        Hooks.driver.findElement(register.registerButton()).click();

    }
    @Then("registration done successfully")
    public void registration_done()
    {
        String color = Hooks.driver. findElement(By.cssSelector("div[class=\"result\"]")).getCssValue("color");
        SoftAssert soft = new SoftAssert();
        soft.assertTrue(Hooks.driver. findElement(By.cssSelector("div[class=\"result\"]")).isDisplayed());
        soft.assertTrue(Hooks.driver.getCurrentUrl().contains("https://demo.nopcommerce.com/registerresult/1?returnUrl=/"));
        soft.assertTrue(Hooks.driver.findElement(By.cssSelector("a[href=\"/customer/info\"][class=\"ico-account\"]")).isDisplayed());
        soft.assertEquals(color,"rgba(76, 177, 124, 1)");
        soft.assertAll();
    }

}