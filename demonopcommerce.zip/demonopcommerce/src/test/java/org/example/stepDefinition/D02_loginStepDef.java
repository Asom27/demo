package org.example.stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P02_login;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

public class D02_loginStepDef {
    WebDriver driver =Hooks.driver;
    P02_login p_login=new P02_login(driver);

    @Given("user navigate to login page")
    public void login_tab()
    {
        driver.findElement(By.xpath("//a[@class=\"ico-login\"]")).click();
    }

    @And("^user enter \"(.*)\" and \"(.*)\"$")
    public void enter_data(String email,String password)
    {
        p_login.login_steps(email,password);
    }
    @And("user click on login button")
    public void click_login_button()
    {
        driver.findElement(By.xpath("//div[@class=\"buttons\"]//button[@type=\"submit\"]")).click();

    }
    @Then("user could login successfully and go to home page")
    public void login_success()
    {
        SoftAssert soft=new SoftAssert();
        soft.assertEquals("https://demo.nopcommerce.com/", driver.getCurrentUrl());
        String my_account=driver.findElement(By.xpath("//a[@class=\"ico-account\"]")).getText();
        soft.assertEquals(my_account,"My account");
        soft.assertAll();
        System.out.println("my account");

    }

}